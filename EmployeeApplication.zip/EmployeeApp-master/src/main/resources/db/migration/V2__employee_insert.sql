INSERT INTO EMPLOYEE (  ID, NAME, DESIGNATION, EMAIL   )
values( 1 ,'RAJ', 'MANAGER', 'raj@gmail.com');