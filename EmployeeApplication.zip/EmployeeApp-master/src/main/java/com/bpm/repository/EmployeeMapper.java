package com.bpm.repository;

import org.apache.ibatis.annotations.Param;

import com.bpm.domain.Employee;

import java.util.List;
//@Mapper
public interface EmployeeMapper {

    public Employee findById(@Param("id") int id);

    public List<Employee> findAllEmployees();

    public void addEmployee(Employee employee);

    public void updateEmployee(Employee employee);

    public void deleteEmployee(int id);

}
